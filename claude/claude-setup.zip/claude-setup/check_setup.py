"""Quality check for the setup: every file in place, every hook wired to a real interpreter and script,
and each hook proven to fire by feeding it a planted bad case and a clean case through the exact
command settings.json runs.

usage: <python> check_setup.py <project folder> <vault folder>
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

CLAUDE = Path(os.environ.get("CLAUDE_CONFIG_DIR") or Path.home() / ".claude")
KIT_HOOKS = ("secret_guard.py", "config_backup.py", "slop_check.py", "session_start.py")
RULES_SIZE_WARN = 8_000
results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  ({detail})" if detail and not ok else ""))


def wired_hooks():
    """Map each kit script name to the [command, *args] settings.json runs for it."""
    settings = json.loads((CLAUDE / "settings.json").read_text(encoding="utf-8"))
    wired = {}
    for groups in settings.get("hooks", {}).values():
        for group in groups:
            for hook in group.get("hooks", []):
                argv = [hook.get("command", ""), *hook.get("args", [])]
                for script in KIT_HOOKS:
                    if any(part.endswith(script) for part in argv):
                        wired[script] = argv
    return wired


def run(argv, event):
    try:
        done = subprocess.run(argv, input=json.dumps(event).encode("utf-8"), capture_output=True, timeout=30)
    except OSError:  # interpreter missing: already reported by check_wiring
        return ""
    return done.stdout.decode("utf-8", errors="replace")


def check_files(project, vault):
    rules = CLAUDE / "CLAUDE.md"
    check("global CLAUDE.md exists", rules.is_file())
    if rules.is_file():
        check("global CLAUDE.md under 8 KB", rules.stat().st_size < RULES_SIZE_WARN,
              f"{rules.stat().st_size} bytes, loaded every session")
    check("project CLAUDE.md exists", (project / "CLAUDE.md").is_file())
    check("SESSION_LOG.md exists", (project / "SESSION_LOG.md").is_file())
    check("MISTAKES.md exists", (project / "MISTAKES.md").is_file())
    check("vault Map.md exists", (vault / "Map.md").is_file())
    for helper in ("reader.md", "drafter.md"):
        check(f"helper agents/{helper} exists", (CLAUDE / "agents" / helper).is_file())


def check_wiring():
    try:
        wired = wired_hooks()
        check("settings.json is valid JSON", True)
    except (OSError, ValueError) as error:
        check("settings.json is valid JSON", False, str(error))
        return {}
    for script in KIT_HOOKS:
        argv = wired.get(script)
        check(f"{script} wired in settings.json", argv is not None)
        if argv:
            placeholder_left = "PYTHON" in argv or any("HOOKS/" in a for a in argv)
            interpreter_found = not placeholder_left and (Path(argv[0]).is_file() or shutil.which(argv[0]) is not None)
            check(f"{script} interpreter exists", interpreter_found, argv[0])
            check(f"{script} script exists", any(Path(a).is_file() for a in argv[1:]), " ".join(argv[1:]))
    return wired


def check_secret_guard(argv):
    cases = [
        ({"tool_name": "Read", "tool_input": {"file_path": "app/.env"}}, True, "a planted .env read"),
        ({"tool_name": "Read", "tool_input": {"file_path": "C:/Users/Zo\u00eb/app/.env"}}, True,
         "a .env under an accented folder"),
        ({"tool_name": "Bash", "tool_input": {"command": "cat .env|head"}}, True, "a piped shell read"),
        ({"tool_name": "PowerShell", "tool_input": {"command": "Get-Content .env"}}, True, "a PowerShell read"),
        ({"tool_name": "Read", "tool_input": {"file_path": "notes.md"}}, False, "an ordinary file"),
        ({"tool_name": "Read", "tool_input": {"file_path": ".env.example"}}, False, "a .env.example"),
        ({"tool_name": "Bash", "tool_input": {"command": 'git commit -m "rotate credentials"'}}, False,
         "a commit naming credentials"),
    ]
    for event, should_deny, label in cases:
        denied = '"deny"' in run(argv, event)
        check(f"secret_guard {'blocks' if should_deny else 'allows'} {label}", denied == should_deny)


def check_slop(argv, scratch):
    note = str(scratch / "note.md")
    flagged = run(argv, {"tool_name": "Write", "tool_input": {"file_path": note, "content": "A robust plan \u2014 trust it.\n"}})
    quiet = run(argv, {"tool_name": "Write", "tool_input": {"file_path": note, "content": "This plan ran twice and matched.\n"}})
    check("slop_check flags a planted machine line", "note.md" in flagged)
    check("slop_check stays quiet on a clean line", quiet.strip() == "")


def check_session_start(argv, scratch):
    (scratch / "SESSION_LOG.md").write_text("~ [2026-01-01] planted \u2192 line\n", encoding="utf-8")
    (scratch / "work" / "demo").mkdir(parents=True)
    (scratch / "work" / "demo" / "STATE.md").write_text("# demo\nNEXT: planted next\n\n---\n", encoding="utf-8")
    opened = run(argv, {"cwd": str(scratch)})
    check("session_start shows the log, non-ASCII included", "planted \u2192 line" in opened)
    check("session_start shows a STATE.md header", "planted next" in opened)


def check_backup(argv, scratch):
    target = scratch / "CLAUDE.md"
    target.write_text("rules\n", encoding="utf-8")
    backups = Path.home() / ".claude" / "setup-backups"
    before = set(backups.glob("*CLAUDE.md*")) if backups.exists() else set()
    run(argv, {"tool_name": "Edit", "tool_input": {"file_path": str(target)}})
    made = (set(backups.glob("*CLAUDE.md*")) if backups.exists() else set()) - before
    check("config_backup copies CLAUDE.md before an edit", len(made) == 1)
    for copy in made:
        copy.unlink()


def main(project, vault):
    check_files(project, vault)
    wired = check_wiring()
    if "secret_guard.py" in wired:
        check_secret_guard(wired["secret_guard.py"])
    with tempfile.TemporaryDirectory() as scratch:
        for script, test in (("slop_check.py", check_slop), ("session_start.py", check_session_start),
                             ("config_backup.py", check_backup)):
            if script in wired:
                test(wired[script], Path(scratch))
    for tool in ("rtk", "icm", "git"):
        print(f"{'ok     ' if shutil.which(tool) else 'MISSING'}  {tool} on PATH (not counted)")
    failed = results.count(False)
    print(f"\n{len(results) - failed} of {len(results)} checks passed")
    return 1 if failed else 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()))
