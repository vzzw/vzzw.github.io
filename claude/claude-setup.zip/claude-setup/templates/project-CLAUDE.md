# <project name>

<one sentence: what this project is>

## Where things go
- Domain knowledge → the vault at <vault path>. Read <vault>/Map.md before working on a named system.
- One piece of work → work/<name>/STATE.md
- One line per finding → SESSION_LOG.md
- Something Claude got wrong → MISTAKES.md

## Never
<one line per answer to question 2; none → delete this section>
