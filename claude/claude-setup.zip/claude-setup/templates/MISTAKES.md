# Mistakes
| date | what went wrong | layer that failed | fix, and where it lives | seen |
|---|---|---|---|---|
