# <name>

PHASE: <where it stands>
NEXT: <the next concrete action>
BLOCKED: <what stops it, or nothing>
DECIDED: <choices made, so they are not reopened>

---
<!-- append below, newest at the bottom; never edit above the line except to update the header -->
[YYYY-MM-DD HH:MM] <what happened, with the numbers>
