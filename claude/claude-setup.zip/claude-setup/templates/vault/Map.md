# Map
Read this first. One line per note: the question it answers → the note.
Write what IS true. Delete a line that stopped being true; git or Obsidian history keeps the old one.
