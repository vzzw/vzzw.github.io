# Map
Read this first. One line per note, starting with `- `, in this form: `- how is X counted → [[Systems/X]]`.
A hook matches your words against the question part of these lines (before `->` or `→`) and shows the note when two words match, so write the question the way you would ask it.
Write what IS true. Delete a line that stopped being true; git or Obsidian history keeps the old one.
