# Session log
<!-- newest at the bottom, one line each.  ~ result  ! problem  + fix  ? open -->

~ [YYYY-MM-DD] <one finding>
