"""PreToolUse: copy a rules or settings file aside before it is edited, so a bad edit is one copy away from undone."""
import json
import shutil
import sys
import time
from pathlib import Path

WATCHED = {"CLAUDE.md", "SKILL.md"}

event = json.loads(sys.stdin.buffer.read())
path = Path(event.get("tool_input", {}).get("file_path", "") or ".")
claude_settings = path.name in ("settings.json", "settings.local.json") and path.parent.name == ".claude"

if (path.name in WATCHED or claude_settings) and path.is_file():
    backups = Path.home() / ".claude" / "setup-backups"
    backups.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    shutil.copy2(path, backups / f"{path.parent.name}__{path.name}.{stamp}")
