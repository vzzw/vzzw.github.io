"""PreCompact: tell the summary what to keep. Claude Code uses this hook's output as instructions for
the compaction summary, so decisions and open work survive and raw tool output does not."""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stdin.buffer.read()
print(
    "When summarising, keep: every decision the person made and their reason, in their words; "
    "the goal they gave at the start; open items and who owns each; file paths and names of what "
    "was changed; numbers that were measured. Drop raw tool output, file listings and anything "
    "already written to a STATE.md. If a STATE.md header is out of date, say so in the summary "
    "so it gets updated first thing after."
)
