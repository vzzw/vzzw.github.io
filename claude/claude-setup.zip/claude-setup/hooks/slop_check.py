"""PostToolUse: after writing prose a person will read, name the new lines that read machine-written."""
import json
import re
import sys
from pathlib import Path

PROSE = {".md", ".txt", ".html"}
SKIP = {"CLAUDE.md"}
TELLS = re.compile(
    r"\u2014|\b(leverage|robust|seamless(ly)?|empower|unlock|delve|dive deep|comprehensive|"
    r"in today's fast-paced|it's worth noting|game[- ]changer)\b",
    re.IGNORECASE,
)

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
event = json.loads(sys.stdin.buffer.read())
tool_input = event.get("tool_input", {})
path = Path(tool_input.get("file_path", "") or ".")
written = tool_input.get("content") or tool_input.get("new_string") or ""

if path.suffix.lower() in PROSE and path.name not in SKIP:
    hits = [line.strip()[:100] for line in written.splitlines() if TELLS.search(line)]
    if hits:
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PostToolUse",
                "additionalContext": (
                    f"The text just written to {path.name} has {len(hits)} line(s) that read "
                    "machine-written (long dash or stock word). Rewrite those lines the way you "
                    "would say them out loud:\n" + "\n".join(hits[:10])
                ),
            }
        }))
