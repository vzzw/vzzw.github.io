"""PreToolUse on Agent: a helper starts only once a model has been picked for its job, so a simple
job never runs on the main session's most expensive model. Built-in helpers (Explore, Plan,
general-purpose) inherit the main model unless the launch passes one."""
import json
import os
import re
import sys
from pathlib import Path

# True = refuse the launch until a model is picked (refused before it starts, so nothing is spent).
# False = let it start; the reminder then arrives with its result and applies to the next launch.
BLOCK = True

PICK = (
    "Set the Agent tool's model parameter for the job: haiku = wording, formatting, pulling fields "
    "out of text · sonnet = reading and gathering facts, routine code, checking work against a "
    "written list · opus = planning, design, debugging something not yet understood, judging "
    "unclear work. Start at the lowest that fits; go up one step only after a check finds a miss."
)

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
event = json.loads(sys.stdin.buffer.read())
tool_input = event.get("tool_input", {})
name = tool_input.get("subagent_type") or "general-purpose"
config = Path(os.environ.get("CLAUDE_CONFIG_DIR") or Path.home() / ".claude")
helper_files = [config / "agents" / f"{name}.md", Path(event.get("cwd") or ".") / ".claude" / "agents" / f"{name}.md"]


def declares_model(path):
    text = path.read_text(encoding="utf-8", errors="replace") if path.is_file() else ""
    return re.search(r"^model:\s*(?!inherit)\S", text, re.MULTILINE) is not None


if not tool_input.get("model") and not any(declares_model(p) for p in helper_files):
    message = f"No model was picked for the '{name}' helper, so it would run on the main session's model. {PICK}"
    output = {"hookEventName": "PreToolUse"}
    if BLOCK:
        output.update(permissionDecision="deny", permissionDecisionReason=message)
    else:
        output["additionalContext"] = "Next helper launch: " + message
    print(json.dumps({"hookSpecificOutput": output}))
