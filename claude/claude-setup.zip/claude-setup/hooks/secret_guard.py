"""PreToolUse: refuse to open a credential file, so a key never lands in the conversation."""
import json
import re
import sys

SECRET_NAME = re.compile(
    r"^(\.env(\.[\w-]+)?|[\w.-]+\.(pem|key|p12|pfx)|id_(rsa|ecdsa|ed25519)|\.netrc|\.npmrc|"
    r"credentials\.json|service-account[\w.-]*\.json|secrets?\.(json|ya?ml|toml))$",
    re.IGNORECASE,
)
HARMLESS = re.compile(r"^\.env\.(example|sample|template|dist)$|^public\.pem$", re.IGNORECASE)
SHELL_SPLIT = re.compile(r"[\s'\"`;|&<>()=,]+")


def is_secret(token):
    if token.replace("\\", "/").endswith(".aws/credentials"):
        return True
    name = re.split(r"[\\/]", token)[-1]
    return bool(SECRET_NAME.match(name)) and not HARMLESS.match(name)


sys.stdout.reconfigure(encoding="utf-8", errors="replace")
event = json.loads(sys.stdin.buffer.read())
tool_input = event.get("tool_input", {})
if event.get("tool_name") in ("Bash", "PowerShell"):
    tokens = SHELL_SPLIT.split(tool_input.get("command", ""))
else:
    tokens = [tool_input.get("file_path") or tool_input.get("path") or ""]

if any(is_secret(token) for token in tokens if token):
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": (
                "That looks like a credential file. Load it inside code that uses the value "
                "without printing it, or ask the person to run the step themselves."
            ),
        }
    }))
