"""UserPromptSubmit: match the words just typed against the questions in the vault's Map.md and show
the notes that may answer it, so Claude reads what is already known before working it out again.

usage in settings.json args: [<this script>, <vault folder>]
Map.md lines look like:  - how is billing counted -> [[Systems/billing]]   (-> or the arrow character)
"""
import json
import re
import sys
from pathlib import Path

MAX_NOTES = 3
ARROW = re.compile("->|→")
STOP = {"this", "that", "with", "what", "when", "where", "which", "there", "their", "about", "would",
        "could", "should", "have", "from", "into", "your", "just", "make", "like", "does", "want", "need",
        "please", "then", "them", "they", "will", "also", "here", "check", "note", "notes"}

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
event = json.loads(sys.stdin.buffer.read())
vault_map = Path(sys.argv[1]) / "Map.md" if len(sys.argv) > 1 else None


def words(text):
    return {w for w in re.findall(r"[a-z0-9_-]{4,}", text.lower()) if w not in STOP}


def matches(question, asked):
    """Two shared words, or one when the map question itself has two words or fewer."""
    shared = len(asked & question)
    return shared, shared >= min(2, len(question))


if vault_map and vault_map.is_file():
    asked = words(event.get("prompt", ""))
    scored = []
    for line in vault_map.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.lstrip().startswith("- ") and ARROW.search(line):
            shared, hit = matches(words(ARROW.split(line, 1)[0]), asked)
            if hit and shared:
                scored.append((shared, line.strip()))
    hits = [line for _, line in sorted(scored, reverse=True)[:MAX_NOTES]]
    if hits:
        print(f"Vault notes that may answer this (vault: {vault_map.parent}). Read them before working it out again:\n"
              + "\n".join(hits))
