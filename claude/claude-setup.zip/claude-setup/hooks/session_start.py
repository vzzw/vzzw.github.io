"""SessionStart: put the end of the log and the header of each active STATE.md in view, so a session starts where the last one stopped."""
import json
import sys
import time
from pathlib import Path

# Set to the project's own layout when it keeps work somewhere other than work/<name>/.
STATE_GLOB = "work/*/STATE.md"
RECENT_DAYS = 14

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
event = json.loads(sys.stdin.buffer.read())
project = Path(event.get("cwd") or ".")

log = project / "SESSION_LOG.md"
if log.is_file():
    tail = log.read_text(encoding="utf-8", errors="replace").splitlines()[-15:]
    print("Last lines of SESSION_LOG.md:\n" + "\n".join(tail))

cutoff = time.time() - RECENT_DAYS * 86400
for state in sorted(project.glob(STATE_GLOB)):
    if state.stat().st_mtime < cutoff:
        continue
    header = state.read_text(encoding="utf-8", errors="replace").split("\n---", 1)[0]
    print(f"\n{state.parent.name}/STATE.md header:\n{header.strip()[:1500]}")
